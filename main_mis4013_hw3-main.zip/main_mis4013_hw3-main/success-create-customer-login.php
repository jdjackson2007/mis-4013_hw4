<?php
$pageTitle = "Account Created Successfully";
include "view-header.php";
?>
  <div class="container">
                <h1>Account Created Successfully!</h1>
                <p>Thank you for creating an account. You can now log in and start using your account.</p>
                <p>If you encounter any issues, please contact our support team.</p>
              <a href="index.php" class="btn btn-secondary">Go to Home</a>
            </div>
               

<?php include "view-footer.php"; ?>


